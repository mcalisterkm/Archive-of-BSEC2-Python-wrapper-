#!/bin/sh
# Add back virtual sensor 18 BSEC_OUTPUT_COMPENSATED_GAS
/usr/bin/cp ./BME68x-Sensor-API/bsec_datatypes.h  ./BSEC_2.2.0.0_Generic_Release_30052022/algo/normal_version/bin/RaspberryPi/PiThree_ArmV6