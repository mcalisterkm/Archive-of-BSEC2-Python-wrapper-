# bme68x-python-library-bsec2.2.0
Temporary clone of the PI3G library to support BOSCH BSEC 2.2.0
This version supports 14 virtual sensors, including the withdrawn BSEC_OUTPUT_GAS_PERCENTAGE.
